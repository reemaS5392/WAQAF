"""Analyse independent expert ratings of the SAB-ZW comparison (Supplementary S4).

Input files (fill in from the expert form; one row per rating):
  instruments/expert_scores.csv     expert_id,model,criterion,score        (score 1-5)
  instruments/expert_relevance.csv  expert_id,criterion,relevance          (relevance 1-4)
Run:    python code/expert_validation_analysis.py
Demo:   python code/expert_validation_analysis.py --demo   (synthetic data, for testing only)

Outputs (outputs/expert_validation.json):
  - content validity of the ten criteria: item-level CVI (share of experts rating 3 or 4)
    and scale-level S-CVI/Ave
  - per-cell expert median and interquartile range; consensus = IQR <= 1
  - agreement with the authors' scores: exact and within-one-point shares, Spearman rho
  - Kendall's W across experts (agreement among experts over the 50 cells)
  - rankings re-computed with the expert median matrix under the three scenarios and
    10,000 Dirichlet weightings (seed 2026)
"""
import csv, json, os, sys
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODELS = ["B1 Conventional administration", "B2 Digital platform", "B3 Blockchain-only",
          "B4 AI-only", "SAB-ZW (proposed)"]
CRIT = [f"C{i}" for i in range(1, 11)]


def rank_avg(x):
    order = np.argsort(x, kind="stable"); r = np.empty(len(x)); r[order] = np.arange(1, len(x) + 1)
    for v in np.unique(x):
        idx = x == v; r[idx] = r[idx].mean()
    return r


def load(demo):
    if demo:
        rng = np.random.default_rng(7)
        A = np.loadtxt(os.path.join(ROOT, "data", "scores.csv"), delimiter=",", skiprows=1,
                       usecols=range(1, 11))
        sc = [(e, MODELS[m], CRIT[c], int(np.clip(A[m, c] + rng.integers(-1, 2), 1, 5)))
              for e in range(1, 8) for m in range(5) for c in range(10)]
        rel = [(e, CRIT[c], int(rng.choice([3, 4, 4, 2], p=[.3, .5, .15, .05])))
               for e in range(1, 8) for c in range(10)]
        return sc, rel
    sc = [(r["expert_id"], r["model"], r["criterion"], int(r["score"]))
          for r in csv.DictReader(open(os.path.join(ROOT, "instruments", "expert_scores.csv")))]
    rel = [(r["expert_id"], r["criterion"], int(r["relevance"]))
           for r in csv.DictReader(open(os.path.join(ROOT, "instruments", "expert_relevance.csv")))]
    return sc, rel


def main(demo=False):
    sc, rel = load(demo)
    experts = sorted({s[0] for s in sc}, key=str)
    E = np.full((len(experts), 5, 10), np.nan)
    for e, m, c, s in sc:
        E[experts.index(e), MODELS.index(m), CRIT.index(c)] = s
    A = np.loadtxt(os.path.join(ROOT, "data", "scores.csv"), delimiter=",", skiprows=1, usecols=range(1, 11))
    med = np.nanmedian(E, 0)
    iqr = np.nanpercentile(E, 75, 0) - np.nanpercentile(E, 25, 0)
    out = {"demo_data": demo, "n_experts": len(experts)}
    # content validity
    R = {}
    for e, c, v in rel:
        R.setdefault(c, []).append(v)
    icvi = {c: round(float(np.mean(np.array(R[c]) >= 3)), 3) for c in CRIT if c in R}
    out["I_CVI"] = icvi; out["S_CVI_Ave"] = round(float(np.mean(list(icvi.values()))), 3)
    out["expert_median"] = med.tolist(); out["expert_IQR"] = iqr.tolist()
    out["cells_with_consensus_IQR_le_1"] = int(np.sum(iqr <= 1))
    d = np.abs(med - A)
    out["agreement_exact_share"] = round(float(np.mean(d == 0)), 3)
    out["agreement_within_one_share"] = round(float(np.mean(d <= 1)), 3)
    ra, rb = rank_avg(A.ravel()), rank_avg(med.ravel())
    out["spearman_rho_authors_vs_experts"] = round(float(np.corrcoef(ra, rb)[0, 1]), 3)
    # Kendall's W across experts over the 50 cells (no tie correction)
    X = E.reshape(len(experts), -1)
    Rk = np.vstack([rank_avg(x) for x in X]); n = X.shape[1]; m = len(experts)
    Ssum = np.sum((Rk.sum(0) - m * (n + 1) / 2) ** 2)
    out["kendalls_W"] = round(float(12 * Ssum / (m ** 2 * (n ** 3 - n))), 3)
    # rankings with expert medians
    W = {"Equal weights": np.ones(10),
         "Governance and Maqasid priority": np.array([1, 2, 1.5, 1, .5, 1, 2, 2, 1, .5]),
         "Efficiency and readiness priority": np.array([1, 1, 1, 1, 2, 1, .5, 1, 1.5, 2.5])}
    out["scenario_totals_expert_median"] = {k: np.round(med @ (w / w.sum()), 2).tolist() for k, w in W.items()}
    D = np.random.default_rng(2026).dirichlet(np.ones(10), 10000)
    out["share_ranked_first_expert_median"] = np.round(
        np.bincount((D @ med.T).argmax(1), minlength=5) / 10000, 4).tolist()
    os.makedirs(os.path.join(ROOT, "outputs"), exist_ok=True)
    fn = "expert_validation_DEMO.json" if demo else "expert_validation.json"
    json.dump(out, open(os.path.join(ROOT, "outputs", fn), "w"), indent=1)
    print(json.dumps({k: v for k, v in out.items() if k not in ("expert_median", "expert_IQR")}, indent=1))


if __name__ == "__main__":
    main(demo="--demo" in sys.argv)
