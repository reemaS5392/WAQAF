"""Data figures for the SAB-ZW paper (called by sabzw_analysis.py)."""
import csv
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.colors import BoundaryNorm, ListedColormap

INK, INK2, GRID, AX = "#0b0b0b", "#52514e", "#e4e3df", "#b5b4ad"
CAT = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#6250d6", "#008300", "#e34948"]
plt.rcParams["font.family"] = "DejaVu Serif"
SHORT = ["B1\nConventional", "B2\nDigital", "B3\nBlockchain", "B4\nAI-only", "SAB-ZW\nProposed"]


def _tidy(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    for s in ("left", "bottom"):
        ax.spines[s].set_color(AX)
    ax.tick_params(colors=INK2, labelsize=8)


def fig_evidence(data_dir, out):
    rows = list(csv.DictReader(open(os.path.join(data_dir, "evidence_base.csv"), encoding="utf-8")))
    streams = ["Governance problems", "Digital platforms & fintech", "Blockchain in Islamic social finance",
               "AI targeting & fraud detection", "AI ethics & Shariah", "AI–blockchain integration & governance",
               "Technical & legal safeguards", "Method & context"]
    years = ["Before 2021", "2021", "2022", "2023", "2024", "2025", "2026"]
    M = np.zeros((len(streams), len(years)), int)
    for r in rows:
        y = int(r["year"])
        M[streams.index(r["stream"]), years.index("Before 2021" if y < 2021 else str(y))] += 1
    fig, ax = plt.subplots(figsize=(8, 4.4), dpi=300)
    bottom = np.zeros(len(years))
    for i, st in enumerate(streams):
        ax.bar(years, M[i], bottom=bottom, color=CAT[i], label=st, width=0.62,
               edgecolor="white", linewidth=1.2, zorder=3)
        bottom += M[i]
    for x, t in enumerate(bottom):
        ax.text(x, t + 0.15, str(int(t)), ha="center", va="bottom", fontsize=8, color=INK)
    ax.set_ylabel("Number of sources", fontsize=9, color=INK)
    ax.set_ylim(0, max(bottom) + 1.2)
    ax.yaxis.set_major_locator(matplotlib.ticker.MaxNLocator(integer=True))
    ax.grid(axis="y", color=GRID, lw=0.6, zorder=0)
    _tidy(ax)
    ax.legend(frameon=False, fontsize=7.2, ncol=3, loc="upper center", bbox_to_anchor=(0.5, 1.24))
    fig.savefig(os.path.join(out, "fig_evidence.png"), bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return {"by_year": dict(zip(years, bottom.astype(int).tolist())),
            "by_stream": dict(zip(streams, M.sum(1).tolist())), "n": int(M.sum())}


def fig_heatmap(S, criteria_labels, out):
    ramp = ListedColormap(["#cde2fb", "#9ec5f4", "#5598e7", "#256abf", "#0d366b"])
    norm = BoundaryNorm([0.5, 1.5, 2.5, 3.5, 4.5, 5.5], 5)
    fig, ax = plt.subplots(figsize=(7.4, 5.4), dpi=300)
    im = ax.imshow(S.T, cmap=ramp, norm=norm, aspect="auto")
    for i in range(S.shape[1]):
        for j in range(S.shape[0]):
            v = int(S[j, i])
            ax.text(j, i, str(v), ha="center", va="center", fontsize=9,
                    color="white" if v >= 4 else INK, weight="bold" if j == 4 else None)
    ax.set_xticks(range(5)); ax.set_xticklabels(SHORT, fontsize=8, color=INK); ax.xaxis.tick_top()
    ax.set_yticks(range(len(criteria_labels))); ax.set_yticklabels(criteria_labels, fontsize=8, color=INK)
    ax.set_xticks(np.arange(-.5, 5), minor=True); ax.set_yticks(np.arange(-.5, 10), minor=True)
    ax.grid(which="minor", color="white", lw=2); ax.tick_params(which="both", length=0)
    for s in ax.spines.values():
        s.set_visible(False)
    cb = fig.colorbar(im, ax=ax, ticks=[1, 2, 3, 4, 5], fraction=0.035, pad=0.02)
    cb.ax.set_yticklabels(["1 Very weak", "2 Weak", "3 Moderate", "4 Strong", "5 Very strong"], fontsize=7.5)
    cb.outline.set_visible(False)
    fig.savefig(os.path.join(out, "fig_heatmap.png"), bbox_inches="tight", facecolor="white")
    plt.close(fig)


def fig_scenarios(res, out):
    sc = list(res["scenarios"].items())
    x = np.arange(5); w = 0.26
    fig, ax = plt.subplots(figsize=(8, 4.2), dpi=300)
    for i, ((name, d), c) in enumerate(zip(sc, CAT[:3])):
        bars = ax.bar(x + (i - 1) * w, d["totals"], w - 0.03, color=c, label=name, zorder=3)
        for b, v in zip(bars, d["totals"]):
            ax.text(b.get_x() + b.get_width() / 2, v + 0.05, f"{v:.2f}", ha="center", va="bottom",
                    fontsize=6.8, color=INK2)
    ax.set_xticks(x); ax.set_xticklabels([s.replace("\n", " (", 1) + ")" if False else s for s in SHORT],
                                         fontsize=8.5, color=INK)
    ax.set_ylim(0, 5); ax.set_ylabel("Weighted score (1–5)", fontsize=9, color=INK)
    ax.grid(axis="y", color=GRID, lw=0.6, zorder=0); _tidy(ax)
    ax.legend(frameon=False, fontsize=8, ncol=3, loc="upper center", bbox_to_anchor=(0.5, 1.12))
    fig.savefig(os.path.join(out, "fig_scenarios.png"), bbox_inches="tight", facecolor="white")
    plt.close(fig)


def fig_robustness(T, res, models, out):
    first = res["random_weights"]["share_ranked_first"]
    fig, ax = plt.subplots(figsize=(8, 3.9), dpi=300)
    bp = ax.boxplot([T[:, i] for i in range(5)], orientation="horizontal", widths=0.55,
                    patch_artist=True, showfliers=False, medianprops=dict(color=INK, lw=1.4),
                    whiskerprops=dict(color=INK2), capprops=dict(color=INK2))
    for i, b in enumerate(bp["boxes"]):
        b.set(facecolor="#256abf" if i == 4 else "#9ec5f4", edgecolor="#184f95", lw=1)
    ax.set_yticks(range(1, 6)); ax.set_yticklabels(models, fontsize=8.5, color=INK)
    for i in range(5):
        ax.text(5.08, i + 1, f"first in {first[i] * 100:.1f}%", va="center", fontsize=8, color=INK)
    ax.set_xlim(1, 5.9); ax.set_xticks([1, 2, 3, 4, 5])
    ax.set_xlabel("Weighted score across 10,000 random weightings (1–5)", fontsize=9, color=INK)
    ax.grid(axis="x", color=GRID, lw=0.6); ax.set_axisbelow(True); _tidy(ax)
    fig.savefig(os.path.join(out, "fig_robustness.png"), bbox_inches="tight", facecolor="white")
    plt.close(fig)


def fig_threshold(S, criteria, models, res, out):
    c10 = criteria.index("C10")
    others = [k for k in range(S.shape[1]) if k != c10]
    g = np.linspace(0, 0.7, 141)
    mo = S[:, others].mean(1)
    fig, ax = plt.subplots(figsize=(8, 4.0), dpi=300)
    cols = ["#9ec5f4", "#eb6834", "#1baf7a", "#eda100", "#256abf"]
    for m in range(5):
        y = g * S[m, c10] + (1 - g) * mo[m]
        ax.plot(g, y, color=cols[m], lw=2.6 if m == 4 else 1.8, zorder=3)
        ax.text(0.705, y[-1], models[m], fontsize=7.6, va="center", color=INK)
    t = res["break_even"]["c10_weight_threshold"]
    ax.axvline(0.1, color=AX, lw=1, ls=":")
    ax.text(0.103, 4.85, "equal weight\n(0.10)", fontsize=7, color=INK2, va="top")
    ax.axvline(t, color=INK2, lw=1, ls="--")
    ax.text(t + 0.006, 4.85, f"threshold {t:.3f}", fontsize=7.5, color=INK, va="top")
    ax.set_xlim(0, 0.7); ax.set_ylim(1.8, 5)
    ax.set_xlabel("Weight on C10 implementation readiness (other nine criteria share the rest equally)",
                  fontsize=8.5, color=INK)
    ax.set_ylabel("Weighted score (1–5)", fontsize=9, color=INK)
    ax.grid(color=GRID, lw=0.6); ax.set_axisbelow(True); _tidy(ax)
    fig.savefig(os.path.join(out, "fig_threshold.png"), bbox_inches="tight", facecolor="white")
    plt.close(fig)


def make_figures(S, criteria, models, res, T, out, data_dir, root):
    labels = {}
    for r in csv.DictReader(open(os.path.join(data_dir, "criteria_operationalisation.csv"), encoding="utf-8")):
        labels[r["code"]] = f'{r["code"]} {r["criterion"]}'
    res["evidence_base"] = fig_evidence(data_dir, out)
    fig_heatmap(S, [labels[c] for c in criteria], out)
    fig_scenarios(res, out)
    fig_robustness(T, res, models, out)
    fig_threshold(S, criteria, models, res, out)
