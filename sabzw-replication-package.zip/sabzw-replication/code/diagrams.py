"""Conceptual diagrams (Figures: SAB-ZW framework and workflow). No data involved.
Run from the repository root:  python code/diagrams.py
"""
import os
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Patch
plt.rcParams["font.family"]="DejaVu Serif"
INK="#0b0b0b"; INK2="#52514e"
OUT=os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),"figures")
os.makedirs(OUT,exist_ok=True)
# ---------- Figure 1: framework ----------
fig,ax=plt.subplots(figsize=(10,7.2),dpi=300); ax.set_xlim(0,100); ax.set_ylim(13,100); ax.axis("off")
def box(x,y,w,h,title,body,fc,ec):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle="round,pad=0.4,rounding_size=1.5",fc=fc,ec=ec,lw=1.2))
    ax.text(x+w/2,y+h-2.6,title,ha="center",va="top",fontsize=9.5,weight="bold",color=INK)
    ax.text(x+w/2,y+h-7.2,body,ha="center",va="top",fontsize=8,color=INK2,linespacing=1.35)
L=[("Layer 5 - Stakeholder Interface Layer","Donor tracking dashboard  |  Beneficiary mobile access\nAuditor & supervisor read-only view  |  Public aggregate reports","#e8f1fb","#2a78d6"),
   ("Layer 4 - Blockchain Trust Layer (permissioned ledger)","Donation & disbursement records  |  Waqf asset registry\nHash of AI output + model version + human decision  |  Smart-contract release after approval","#e6f6f0","#1baf7a"),
   ("Layer 3 - AI Intelligence Layer (decision support only)","Need & eligibility scoring with explanations (XAI)  |  Anomaly / fraud detection\nCollection & demand forecasting  |  Waqf asset performance monitoring","#fdeee7","#eb6834"),
   ("Layer 2 - Data & Identity Layer","Consented data, minimised and encrypted off-chain\nVerified identities  |  Only hashes/pointers stored on-chain","#f3f1fb","#6250d6"),
   ("Layer 1 - Shariah Governance & Policy Layer","Shariah board approval gate  |  Eligibility (asnaf) and waqf rules set by the institution\nApplicable laws and supervisory requirements","#fdf5e0","#eda100")]
y=82
for t,b,fc,ec in L:
    box(1,y,80,13,t,b,fc,ec); y-=16.5
# cross-cutting bar
ax.add_patch(FancyBboxPatch((85,16.5),13,78.5,boxstyle="round,pad=0.4,rounding_size=1.5",fc="#f4f4f2",ec="#52514e",lw=1.0))
ax.text(91.5,56,"CROSS-CUTTING\nCONTROLS\n\nSmart-contract\nsecurity audit\n\nModel validation\n& bias testing\n\nPrivacy by\ndesign\n\nHuman review\nlog & appeal\n\nFeedback &\ncontinuous\nimprovement",ha="center",va="center",fontsize=7.4,rotation=0,color=INK,linespacing=1.4)
for yy in [80.5,64,47.5,31]:
    ax.annotate("",xy=(41,yy+1.2),xytext=(41,yy-2.6),arrowprops=dict(arrowstyle="<|-|>",color=INK2,lw=1.1,mutation_scale=9))
fig.savefig(os.path.join(OUT,"fig_framework.png"),bbox_inches="tight",facecolor="white"); plt.close(fig)


# ---------- Workflow ----------
fig,ax=plt.subplots(figsize=(10,4.8),dpi=300); ax.set_xlim(0,100); ax.set_ylim(0,52); ax.axis("off")
ACT={"Blockchain trust layer":("#e6f6f0","#1baf7a"),"Data & identity layer":("#f3f1fb","#6250d6"),
     "AI intelligence layer":("#fdeee7","#eb6834"),"Human / Shariah governance":("#fdf5e0","#eda100"),"Stakeholder interface":("#e8f1fb","#2a78d6")}
steps=[("1","Donation received","recorded on the","permissioned ledger","Blockchain trust layer"),
       ("2","Application verified","personal data stored","off-chain with consent","Data & identity layer"),
       ("3","AI recommendation","need & eligibility score,","explanation, anomaly flags","AI intelligence layer"),
       ("4","Human decision","staff / Shariah board","approve or reject","Human / Shariah governance"),
       ("5","Decision recorded","hash of AI output, model","version & human decision","Blockchain trust layer"),
       ("6","Disbursement","smart contract releases","the approved amount","Blockchain trust layer"),
       ("7","Reporting & appeal","dashboards and reports","update; appeal channel","Stakeholder interface")]
W,Hh=22.5,16
pos=[(1,30),(25.5,30),(50,30),(74.5,30),(74.5,3),(50,3),(25.5,3)]
for (n,t,l1,l2,act),(x,y) in zip(steps,pos):
    fc,ec=ACT[act]
    ax.add_patch(FancyBboxPatch((x,y),W,Hh,boxstyle="round,pad=0.3,rounding_size=1.2",fc=fc,ec=ec,lw=1.4))
    ax.add_patch(plt.Circle((x+2.4,y+Hh-2.6),1.7,color=ec,zorder=4))
    ax.text(x+2.4,y+Hh-2.6,n,ha="center",va="center",fontsize=7.5,color="white",weight="bold",zorder=5)
    ax.text(x+5,y+Hh-2.6,t,ha="left",va="center",fontsize=8.3,weight="bold",color=INK)
    ax.text(x+W/2,y+Hh/2-1.4,l1+"\n"+l2,ha="center",va="center",fontsize=7.4,color=INK2,linespacing=1.35)
ar=dict(arrowstyle="-|>",color=INK2,lw=1.2,mutation_scale=11)
for i in range(3): ax.annotate("",xy=(pos[i+1][0]-0.5,38),xytext=(pos[i][0]+W+0.5,38),arrowprops=ar)
ax.annotate("",xy=(85.75,19.6),xytext=(85.75,29.5),arrowprops=ar)
ax.text(87,24.5,"if approved",fontsize=7,color=INK2,va="center")
ax.annotate("",xy=(50+W+0.5,11),xytext=(74.5-0.5,11),arrowprops=ar)
ax.annotate("",xy=(25.5+W+0.5,11),xytext=(50-0.5,11),arrowprops=ar)
ax.annotate("",xy=(36.75,29.5),xytext=(85.75-12,29.5),arrowprops=dict(arrowstyle="-|>",color=INK2,lw=1,ls="--",mutation_scale=10,connectionstyle="arc3,rad=-0.18"))
ax.text(55,21.2,"if rejected: returned to step 2 with recorded reasons",fontsize=7,color=INK2,ha="center")
ax.text(12.25,11,"Appeals and outcomes\nfeed periodic review of\nAI models and rules\n(cross-cutting control)",fontsize=7,color=INK2,ha="center",va="center",linespacing=1.35)
ax.legend(handles=[Patch(fc=v[0],ec=v[1],label=k) for k,v in ACT.items()],frameon=False,fontsize=7.5,ncol=5,loc="upper center",bbox_to_anchor=(0.5,1.08))
fig.savefig(os.path.join(OUT,"fig_workflow.png"),bbox_inches="tight",facecolor="white"); plt.close(fig)

