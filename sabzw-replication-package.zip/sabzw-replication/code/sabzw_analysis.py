"""SAB-ZW comparative evaluation: complete, reproducible analysis.

Reproduces every number, table and data figure reported in:
"Integrating Artificial Intelligence and Blockchain for Zakat and Waqf Management:
A Shariah-Governed Conceptual Framework and Comparative Benchmark Analysis".

Usage (from the repository root):
    python code/sabzw_analysis.py
Inputs : data/scores.csv, data/weight_scenarios.csv
Outputs: outputs/*.json|csv and figures/*.png

Random procedures use NumPy's default_rng (PCG64) with seed 2026.
The order of random draws is fixed (weights first, then score perturbations),
so the reported shares are reproduced exactly.
"""
import csv
import json
import os
import platform
import sys

import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data")
OUT = os.path.join(ROOT, "outputs")
FIG = os.path.join(ROOT, "figures")
SEED = 2026
N_DRAWS = 10_000


def read_matrix(path):
    with open(path, newline="", encoding="utf-8") as f:
        rows = list(csv.reader(f))
    header, body = rows[0], rows[1:]
    names = [r[0] for r in body]
    values = np.array([[float(x) for x in r[1:]] for r in body])
    return header[1:], names, values


def ranks(totals):
    """Competition ranks (1 = best); ties share the better rank."""
    return [1 + int(np.sum(totals > t + 1e-12)) for t in totals]


def main():
    os.makedirs(OUT, exist_ok=True)
    os.makedirs(FIG, exist_ok=True)
    criteria, models, S = read_matrix(os.path.join(DATA, "scores.csv"))
    _, scen_names, W_raw = read_matrix(os.path.join(DATA, "weight_scenarios.csv"))
    n_models, n_crit = S.shape
    P = models.index("SAB-ZW (proposed)")
    res = {"criteria": criteria, "models": models, "scores": S.tolist(),
           "unweighted_totals": S.sum(1).tolist()}

    # 1. Fixed weighting scenarios -------------------------------------------------
    res["scenarios"] = {}
    for name, w in zip(scen_names, W_raw):
        wn = w / w.sum()
        tot = S @ wn
        res["scenarios"][name] = {"weights_normalised": np.round(wn, 4).tolist(),
                                  "totals": np.round(tot, 2).tolist(),
                                  "ranks": ranks(np.round(tot, 6))}

    # 2. Stochastic weights (SMAA-style rank acceptability) -------------------------
    rng = np.random.default_rng(SEED)
    D = rng.dirichlet(np.ones(n_crit), N_DRAWS)           # uniform over the weight simplex
    T = D @ S.T                                             # draws x models
    order = np.argsort(-T, axis=1, kind="stable")
    rank_of = np.empty_like(order)
    rows = np.arange(N_DRAWS)[:, None]
    rank_of[rows, order] = np.arange(n_models)[None, :]
    acc = np.zeros((n_models, n_models))
    for m in range(n_models):
        acc[m] = np.bincount(rank_of[:, m], minlength=n_models) / N_DRAWS
    first_share = np.bincount(T.argmax(1), minlength=n_models) / N_DRAWS
    pct = np.percentile(T, [5, 25, 50, 75, 95], axis=0)
    res["random_weights"] = {
        "draws": N_DRAWS, "seed": SEED, "distribution": "Dirichlet(1,...,1)",
        "share_ranked_first": np.round(first_share, 4).tolist(),
        "rank_acceptability": np.round(acc, 4).tolist(),
        "p5": np.round(pct[0], 2).tolist(), "p25": np.round(pct[1], 2).tolist(),
        "median": np.round(pct[2], 2).tolist(), "p75": np.round(pct[3], 2).tolist(),
        "p95": np.round(pct[4], 2).tolist(),
    }
    # draws where SAB-ZW is not first: mean weight on each criterion
    lost = T.argmax(1) != P
    res["random_weights"]["mean_weights_when_proposed_not_first"] = (
        np.round(D[lost].mean(0), 3).tolist() if lost.any() else None)

    # 3. Score perturbation (each score +-1, clipped to 1..5, equal weights) ---------
    eq = np.ones(n_crit) / n_crit
    wins = 0
    for _ in range(N_DRAWS):
        Sp = np.clip(S + rng.integers(-1, 2, S.shape), 1, 5)
        wins += int((Sp @ eq).argmax() == P)
    res["score_perturbation"] = {"draws": N_DRAWS, "share_proposed_first": wins / N_DRAWS}

    # 4. Leave-one-criterion-out (equal weights) ------------------------------------
    loo = []
    for j, c in enumerate(criteria):
        keep = [k for k in range(n_crit) if k != j]
        tot = S[:, keep].mean(1)
        loo.append({"dropped": c, "totals": np.round(tot, 2).tolist(),
                    "rank_proposed": ranks(np.round(tot, 6))[P]})
    res["leave_one_out"] = loo

    # 5. Break-even analyses --------------------------------------------------------
    rival = max((S[m].sum(), m) for m in range(n_models) if m != P)
    gap = S[P].sum() - rival[0]
    res["break_even"] = {
        "best_rival_equal_weights": models[rival[1]],
        "unweighted_gap_points": float(gap),
        "one_point_reductions_to_tie": int(gap),
        "one_point_reductions_to_lose_first": int(gap) + 1,
    }
    # weight on C10 (others equal) at which the proposed framework stops ranking first
    c10 = criteria.index("C10")
    grid = np.linspace(0, 1, 100001)
    others = [k for k in range(n_crit) if k != c10]
    mean_others = S[:, others].mean(1)
    curves = np.outer(grid, S[:, c10]) + np.outer(1 - grid, mean_others)
    best = curves.argmax(1)
    idx = int(np.argmax(best != P))
    res["break_even"]["c10_weight_threshold"] = round(float(grid[idx]), 4)
    res["break_even"]["c10_threshold_overtaken_by"] = models[int(best[idx])]
    res["break_even"]["c10_threshold_multiple_of_equal_weight"] = round(float(grid[idx]) / 0.1, 2)
    with open(os.path.join(OUT, "weight_threshold_curve.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["c10_weight"] + models)
        for g in np.linspace(0, 1, 101):
            w.writerow([round(g, 2)] + [round(g * S[m, c10] + (1 - g) * mean_others[m], 4)
                                         for m in range(n_models)])

    # 6. Save outputs ---------------------------------------------------------------
    res["environment"] = {"python": sys.version.split()[0], "numpy": np.__version__,
                          "platform": platform.platform()}
    with open(os.path.join(OUT, "results.json"), "w") as f:
        json.dump(res, f, indent=1)
    with open(os.path.join(OUT, "rank_acceptability.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["model"] + [f"rank_{k + 1}" for k in range(n_models)])
        for m in range(n_models):
            w.writerow([models[m]] + [round(x, 4) for x in acc[m]])
    with open(os.path.join(OUT, "leave_one_out.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["dropped_criterion"] + models + ["rank_of_proposed"])
        for r in loo:
            w.writerow([r["dropped"]] + r["totals"] + [r["rank_proposed"]])
    np.savetxt(os.path.join(OUT, "random_weight_totals_sample.csv"), T[:200], delimiter=",",
               header=",".join(models), comments="", fmt="%.4f")

    # 7. Figures --------------------------------------------------------------------
    try:
        from figures_data import make_figures
        make_figures(S, criteria, models, res, T, FIG, DATA, ROOT)
        with open(os.path.join(OUT, "results.json"), "w") as f:
            json.dump(res, f, indent=1)
    except ImportError as e:  # plotting is optional for reproducing the numbers
        print("figures skipped:", e)

    r = res
    print("Weighted totals:")
    for k, v in r["scenarios"].items():
        print(f"  {k:36s}", v["totals"], "ranks", v["ranks"])
    print("Share ranked first (random weights):", r["random_weights"]["share_ranked_first"])
    print("Median / p5 / p95:", r["random_weights"]["median"], r["random_weights"]["p5"], r["random_weights"]["p95"])
    print("Score perturbation, proposed first:", r["score_perturbation"]["share_proposed_first"])
    print("Leave-one-out rank of proposed:", [x["rank_proposed"] for x in loo])
    print("Break-even:", r["break_even"])


if __name__ == "__main__":
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    main()
