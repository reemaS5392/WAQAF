# SAB-ZW replication package

Replication materials for:
**"Integrating Artificial Intelligence and Blockchain for Zakat and Waqf Management: A Shariah-Governed Conceptual Framework and Comparative Benchmark Analysis"** (revised manuscript, 2026).

The study uses only secondary, published sources. No personal or proprietary data are included.

## Contents

| Path | What it is |
|---|---|
| `data/scores.csv` | The 5 × 10 scoring matrix (models × criteria), scores 1–5 |
| `data/score_justification.csv` | Rationale and source keys for each of the 50 scores |
| `data/criteria_operationalisation.csv` | Operational question and 1/3/5 anchors for each criterion |
| `data/weight_scenarios.csv` | Raw weights of the three weighting scenarios (normalised in code) |
| `data/evidence_base.csv` | The 38 sources: year, type, research stream, DOI/URL, how verified |
| `code/sabzw_analysis.py` | Complete analysis: scenarios, random weights, perturbation, leave-one-out, break-even |
| `code/figures_data.py` | Data figures (called by the analysis script) |
| `code/diagrams.py` | Framework and workflow diagrams (no data) |
| `code/expert_validation_analysis.py` | Analysis of independent expert ratings (CVI, Kendall's W, agreement, re-ranking) |
| `instruments/Expert_Validation_Form.docx` | Form sent to experts; blank CSV templates for transcribing ratings |
| `outputs/` | Results produced by the code (`results.json`, rank acceptability, leave-one-out, threshold curve) |
| `figures/` | All figures as PNG (300 dpi) |
| `tests/check_reproduction.py` | Compares a fresh run with every number reported in the paper |

## Reproduce

```bash
python -m venv venv && source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt                       # numpy 2.5.3, matplotlib 3.11.2 (Python 3.13)
python code/sabzw_analysis.py                         # writes outputs/ and data figures
python code/diagrams.py                               # writes the two diagrams
python tests/check_reproduction.py                    # prints ALL CHECKS PASSED
```

Run time is under a minute on a laptop. The results were reproduced in a fresh virtual environment
with the pinned versions before release.

## Procedure

1. **Scores.** Each model receives a score from 1 (very weak) to 5 (very strong) on criteria C1–C10,
   using the anchors in `criteria_operationalisation.csv`. Every score is linked to published evidence
   in `score_justification.csv`.
2. **Fixed scenarios.** Raw weights in `weight_scenarios.csv` are divided by their sum; the weighted
   score of each model is the scores × normalised weights.
3. **Random weights (SMAA-style).** 10,000 weight vectors are drawn from a uniform Dirichlet(1,…,1)
   distribution with `numpy.random.default_rng(2026)`. For each draw the models are ranked; the share
   of draws in which each model holds each rank is the rank acceptability index.
4. **Score perturbation.** Using the same generator (after step 3), every score is shifted by −1, 0 or
   +1 (uniform), clipped to 1–5, and models are ranked under equal weights; 10,000 repetitions.
5. **Leave-one-criterion-out.** Rankings under equal weights with each criterion removed in turn.
6. **Break-even.** (a) Number of one-point reductions in the proposed framework's scores needed to lose
   first place under equal weights; (b) the weight on C10 (implementation readiness), with the other
   nine criteria sharing the remainder equally, at which the proposed framework stops ranking first.

The order of random draws matters for exact reproduction: do not reorder steps 3 and 4.

## Key results (reproduced by `tests/check_reproduction.py`)

* Weighted scores of SAB-ZW: 4.20 (equal), 4.40 (governance priority), 3.92 (efficiency priority).
* Ranked first in 97.08% of random weightings; median 4.22 (5th–95th percentile 3.70–4.58).
* Ranked first in 96.56% of score perturbations; first in all ten leave-one-out cases.
* Loses first place only after 9 one-point score reductions, or if C10 receives more than 35.7% of the
  total weight (3.6 times the equal weight).

## Licence

Code: MIT licence (`LICENSE`). Data, outputs and figures: CC BY 4.0.

## Citation

See `CITATION.cff`.
