"""Checks that a fresh run reproduces every number reported in the paper.
Run:  python code/sabzw_analysis.py && python tests/check_reproduction.py
"""
import json, os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
r = json.load(open(os.path.join(ROOT, "outputs", "results.json")))
EXPECTED = {
    ("scenarios", "Equal weights", "totals"): [2.8, 3.4, 3.1, 2.8, 4.2],
    ("scenarios", "Governance and Maqasid priority", "totals"): [2.88, 3.32, 3.08, 2.6, 4.4],
    ("scenarios", "Efficiency and readiness priority", "totals"): [2.96, 3.56, 3.0, 2.96, 3.92],
    ("random_weights", "share_ranked_first"): [0.0106, 0.0186, 0.0, 0.0, 0.9708],
    ("random_weights", "median"): [2.76, 3.39, 3.08, 2.79, 4.22],
    ("random_weights", "p5"): [2.3, 3.17, 2.65, 2.39, 3.7],
    ("random_weights", "p95"): [3.45, 3.65, 3.6, 3.25, 4.58],
    ("score_perturbation", "share_proposed_first"): 0.9656,
    ("break_even", "one_point_reductions_to_lose_first"): 9,
    ("break_even", "c10_weight_threshold"): 0.3572,
}
fail = 0
for path, exp in EXPECTED.items():
    v = r
    for k in path:
        v = v[k]
    ok = v == exp
    fail += not ok
    print(("PASS " if ok else "FAIL ") + " / ".join(path), v if not ok else "")
loo = [x["rank_proposed"] for x in r["leave_one_out"]]
ok = loo == [1] * 10; fail += not ok
print(("PASS " if ok else "FAIL ") + "leave-one-out: proposed ranked first in all 10 cases")
print("ALL CHECKS PASSED" if not fail else f"{fail} CHECK(S) FAILED")
sys.exit(1 if fail else 0)
